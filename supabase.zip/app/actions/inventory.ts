"use server"

import { revalidatePath } from "next/cache"
import { getServiceSupabase } from "@/lib/supabase"
import { revalidateProductCache } from "@/lib/products"
import type { Product, ProductStatus, InventoryUpdateLog } from "@/types/inventory"
import type { Omit } from "@/types/utils"
import type { Partial } from "@/types/utils"

// Get Supabase admin client
const getSupabase = () => getServiceSupabase()

// Get all products
export async function getProducts(includeDiscontinued = true): Promise<Product[]> {
  try {
    const supabase = getSupabase()
    let query = supabase.from("products").select("*").order("updated_at", { ascending: false })

    // Filter out discontinued products if not explicitly included
    if (!includeDiscontinued) {
      query = query.neq("inventory_status", "discontinued")
    }

    const { data, error } = await query

    if (error) throw error

    // Transform database model to our application model
    return data.map((product) => ({
      id: product.id,
      name: product.name,
      description: product.description || "",
      price: product.price,
      compareAtPrice: product.compare_at_price || undefined,
      images: product.images,
      category: product.category || "",
      tags: product.tags,
      sku: product.sku,
      barcode: product.barcode || undefined,
      inventory: {
        quantity: product.inventory_quantity,
        lowStockThreshold: product.low_stock_threshold,
        status: product.inventory_status,
        managed: product.inventory_managed,
      },
      attributes: product.attributes || {},
      createdAt: product.created_at,
      updatedAt: product.updated_at,
    }))
  } catch (error) {
    console.error("Failed to get products:", error)
    throw error
  }
}

// Get product by ID
export async function getProductById(id: string): Promise<Product | null> {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase.from("products").select("*").eq("id", id).single()

    if (error) {
      if (error.code === "PGRST116") return null // No rows returned
      throw error
    }

    if (!data) return null

    // Transform database model to our application model
    return {
      id: data.id,
      name: data.name,
      description: data.description || "",
      price: data.price,
      compareAtPrice: data.compare_at_price || undefined,
      images: data.images,
      category: data.category || "",
      tags: data.tags,
      sku: data.sku,
      barcode: data.barcode || undefined,
      inventory: {
        quantity: data.inventory_quantity,
        lowStockThreshold: data.low_stock_threshold,
        status: data.inventory_status,
        managed: data.inventory_managed,
      },
      attributes: data.attributes || {},
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    }
  } catch (error) {
    console.error("Failed to get product by ID:", error)
    throw error
  }
}

// Create a new product
export async function createProduct(
  productData: Omit<Product, "id" | "createdAt" | "updatedAt">,
): Promise<{ success: boolean; product?: Product; error?: string }> {
  try {
    const supabase = getSupabase()

    const { data, error } = await supabase
      .from("products")
      .insert([
        {
          name: productData.name,
          description: productData.description,
          price: productData.price,
          compare_at_price: productData.compareAtPrice,
          images: productData.images,
          category: productData.category,
          tags: productData.tags,
          sku: productData.sku,
          barcode: productData.barcode,
          inventory_quantity: productData.inventory.quantity,
          low_stock_threshold: productData.inventory.lowStockThreshold,
          inventory_managed: productData.inventory.managed,
          inventory_status: productData.inventory.status,
          attributes: productData.attributes || {},
        },
      ])
      .select("*")
      .single()

    if (error) throw error

    // Revalidate paths and cache
    revalidatePath("/admin/products")
    await revalidateProductCache() // Revalidate product cache

    // Transform database model to our application model
    return {
      success: true,
      product: {
        id: data.id,
        name: data.name,
        description: data.description || "",
        price: data.price,
        compareAtPrice: data.compare_at_price || undefined,
        images: data.images,
        category: data.category || "",
        tags: data.tags,
        sku: data.sku,
        barcode: data.barcode || undefined,
        inventory: {
          quantity: data.inventory_quantity,
          lowStockThreshold: data.low_stock_threshold,
          status: data.inventory_status,
          managed: data.inventory_managed,
        },
        attributes: data.attributes || {},
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      },
    }
  } catch (error) {
    console.error("Failed to create product:", error)
    return { success: false, error: "Failed to create product" }
  }
}

// Update a product
export async function updateProduct(
  id: string,
  productData: Partial<Product>,
): Promise<{ success: boolean; product?: Product; error?: string }> {
  try {
    const supabase = getSupabase()

    const { data, error } = await supabase
      .from("products")
      .update({
        name: productData.name,
        description: productData.description,
        price: productData.price,
        compare_at_price: productData.compareAtPrice,
        images: productData.images,
        category: productData.category,
        tags: productData.tags,
        sku: productData.sku,
        barcode: productData.barcode,
        inventory_quantity: productData.inventory?.quantity,
        low_stock_threshold: productData.inventory?.lowStockThreshold,
        inventory_managed: productData.inventory?.managed,
        inventory_status: productData.inventory?.status,
        attributes: productData.attributes || {},
      })
      .eq("id", id)
      .select("*")
      .single()

    if (error) throw error

    // Revalidate paths and cache
    revalidatePath("/admin/products")
    revalidatePath(`/admin/products/${id}`)
    await revalidateProductCache() // Revalidate product cache

    // Transform database model to our application model
    return {
      success: true,
      product: {
        id: data.id,
        name: data.name,
        description: data.description || "",
        price: data.price,
        compareAtPrice: data.compare_at_price || undefined,
        images: data.images,
        category: data.category || "",
        tags: data.tags,
        sku: data.sku,
        barcode: data.barcode || undefined,
        inventory: {
          quantity: data.inventory_quantity,
          lowStockThreshold: data.low_stock_threshold,
          status: data.inventory_status,
          managed: data.inventory_managed,
        },
        attributes: data.attributes || {},
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      },
    }
  } catch (error) {
    console.error("Failed to update product:", error)
    return { success: false, error: "Failed to update product" }
  }
}

// Delete a product
export async function deleteProduct(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = getSupabase()

    // Check if the product is referenced in any orders
    const { count, error: checkError } = await supabase
      .from("order_items")
      .select("*", { count: "exact", head: true })
      .eq("product_id", id)

    if (checkError) {
      console.error("Error checking order items:", checkError)
    }

    // If product is used in orders, return an error
    if (count && count > 0) {
      return {
        success: false,
        error: "Cannot delete product that has been ordered. Consider marking it as discontinued instead.",
      }
    }

    // First delete related inventory logs
    await supabase.from("inventory_logs").delete().eq("product_id", id)

    // Then delete the product
    const { error } = await supabase.from("products").delete().eq("id", id)

    if (error) {
      console.error("Delete product error:", error)
      return { success: false, error: error.message || "Failed to delete product" }
    }

    // Revalidate paths and cache
    revalidatePath("/admin/products")
    await revalidateProductCache() // Revalidate product cache

    return { success: true }
  } catch (error) {
    console.error("Failed to delete product:", error)
    return { success: false, error: "Failed to delete product" }
  }
}

// Update inventory quantity
export async function updateInventory(
  productId: string,
  newQuantity: number,
  reason: string,
  orderId?: string,
  userId?: string,
): Promise<{ success: boolean; product?: Product; log?: InventoryUpdateLog; error?: string }> {
  try {
    const supabase = getSupabase()

    // Get current product
    const { data: product, error: productError } = await supabase
      .from("products")
      .select("*")
      .eq("id", productId)
      .single()

    if (productError || !product) {
      console.error("Product fetch error:", productError)
      return { success: false, error: "Product not found" }
    }

    const previousQuantity = product.inventory_quantity

    // Determine new status
    const newStatus = determineProductStatus(newQuantity, product.low_stock_threshold)

    // Update product
    const { data: updatedProduct, error: updateError } = await supabase
      .from("products")
      .update({
        inventory_quantity: newQuantity,
        inventory_status: newStatus,
        updated_at: new Date().toISOString(),
      })
      .eq("id", productId)
      .select("*")
      .single()

    if (updateError) {
      console.error("Product update error:", updateError)
      return { success: false, error: "Failed to update product" }
    }

    // Create inventory log
    const { data: log, error: logError } = await supabase
      .from("inventory_logs")
      .insert([
        {
          product_id: productId,
          previous_quantity: previousQuantity,
          new_quantity: newQuantity,
          reason,
          order_id: orderId,
          user_id: userId,
          timestamp: new Date().toISOString(),
        },
      ])
      .select("*")
      .single()

    if (logError) {
      console.error("Log creation error:", logError)
      // Continue even if log creation fails
    }

    // Revalidate paths and cache
    revalidatePath("/admin/products")
    revalidatePath(`/admin/products/${productId}`)
    revalidatePath("/admin/inventory")
    await revalidateProductCache() // Revalidate product cache

    // Transform database models to our application models
    return {
      success: true,
      product: {
        id: updatedProduct.id,
        name: updatedProduct.name,
        description: updatedProduct.description || "",
        price: updatedProduct.price,
        compareAtPrice: updatedProduct.compare_at_price || undefined,
        images: updatedProduct.images,
        category: updatedProduct.category || "",
        tags: updatedProduct.tags,
        sku: updatedProduct.sku,
        barcode: updatedProduct.barcode || undefined,
        inventory: {
          quantity: updatedProduct.inventory_quantity,
          lowStockThreshold: updatedProduct.low_stock_threshold,
          status: updatedProduct.inventory_status,
          managed: updatedProduct.inventory_managed,
        },
        attributes: updatedProduct.attributes || {},
        createdAt: updatedProduct.created_at,
        updatedAt: updatedProduct.updated_at,
      },
      log: log
        ? {
            id: log.id,
            productId: log.product_id,
            previousQuantity: log.previous_quantity,
            newQuantity: log.new_quantity,
            reason: log.reason,
            orderId: log.order_id || undefined,
            userId: log.user_id || undefined,
            timestamp: log.timestamp,
          }
        : undefined,
    }
  } catch (error) {
    console.error("Failed to update inventory:", error)
    return { success: false, error: "Failed to update inventory" }
  }
}

// Helper function to determine product status based on quantity
function determineProductStatus(quantity: number, lowStockThreshold: number): ProductStatus {
  if (quantity <= 0) {
    return "out_of_stock"
  } else if (quantity <= lowStockThreshold) {
    return "low_stock"
  } else {
    return "in_stock"
  }
}

export async function getInventoryLogs(productId?: string): Promise<InventoryUpdateLog[]> {
  try {
    const supabase = getSupabase()

    // Build the query
    let query = supabase.from("inventory_logs").select("*").order("timestamp", { ascending: false })

    // Add filter if productId is provided
    if (productId) {
      query = query.eq("product_id", productId)
    }

    // Execute the query
    const { data, error } = await query

    if (error) throw error

    // Transform database models to our application models
    return data.map((log) => ({
      id: log.id,
      productId: log.product_id,
      previousQuantity: log.previous_quantity,
      newQuantity: log.new_quantity,
      reason: log.reason,
      orderId: log.order_id || undefined,
      userId: log.user_id || undefined,
      timestamp: log.timestamp,
    }))
  } catch (error) {
    console.error("Failed to get inventory logs:", error)
    throw error
  }
}

