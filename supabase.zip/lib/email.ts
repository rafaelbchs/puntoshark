import { Resend } from "resend"
import { getSettings } from "@/app/actions/settings"
import type { Order } from "@/types/checkout"

// Initialize Resend with API key
const resend = new Resend(process.env.RESEND_API_KEY)

// Function to send emails using Resend
export async function sendEmail(to: string, subject: string, html: string) {
  try {
    // Get store settings for the from address
    const settings = await getSettings()
    const storeSettings = settings.store
    const storeName = storeSettings?.storeName || "Our Store"

    // You can customize this with your own domain once you set it up in Resend
    const fromEmail = process.env.RESEND_FROM_EMAIL || "onboarding@resend.dev"

    // Send email using Resend
    const { data, error } = await resend.emails.send({
      from: `${storeName} <${fromEmail}>`,
      to: [to],
      subject: subject,
      html: html,
    })

    if (error) {
      console.error("Resend API error:", error)
      throw new Error(`Failed to send email: ${error.message}`)
    }

    console.log("Email sent successfully:", data)
    return { success: true, data }
  } catch (error) {
    console.error("Failed to send email:", error)
    return { success: false, error }
  }
}

// Function to render email template with variables
export function renderEmailTemplate(template: string, data: Record<string, any>): string {
  let rendered = template

  // Replace simple variables
  for (const key in data) {
    if (typeof data[key] !== "object") {
      const regex = new RegExp(`{{\\s*${key}\\s*}}`, "g")
      rendered = rendered.replace(regex, String(data[key]))
    }
  }

  // Handle each loops
  const eachRegex = /{{#each\s+(\w+)\s*}}([\s\S]*?){{\/each}}/g
  let match

  while ((match = eachRegex.exec(template)) !== null) {
    const arrayName = match[1]
    const itemTemplate = match[2]
    const fullMatch = match[0]

    if (data[arrayName] && Array.isArray(data[arrayName])) {
      const renderedItems = data[arrayName]
        .map((item: any) => {
          let itemRendered = itemTemplate
          for (const key in item) {
            if (typeof item[key] !== "object") {
              const itemRegex = new RegExp(`{{\\s*${key}\\s*}}`, "g")
              itemRendered = itemRendered.replace(itemRegex, String(item[key]))
            }
          }
          return itemRendered
        })
        .join("")

      rendered = rendered.replace(fullMatch, renderedItems)
    }
  }

  return rendered
}

// Send order confirmation email
export async function sendOrderConfirmationEmail(order: Order): Promise<{ success: boolean; error?: any }> {
  try {
    // Get notification settings
    const settings = await getSettings()
    const notificationSettings = settings.notifications

    // Check if email notifications are enabled
    if (!notificationSettings?.emailNotifications || !notificationSettings.orderConfirmation) {
      console.log("Order confirmation emails are disabled in settings")
      return { success: false, error: "Email notifications are disabled" }
    }

    // Get email template
    const emailTemplate =
      notificationSettings.emailTemplate ||
      `
      <h1>Thank you for your order!</h1>
      <p>Dear {{customerName}},</p>
      <p>We're pleased to confirm your order #{{orderId}}.</p>
      <h2>Order Details:</h2>
      <ul>
        {{#each items}}
        <li>{{quantity}}x {{name}} - ${{ price }}</li>
        {{/each}}
      </ul>
      <p><strong>Total: ${{ total }}</strong></p>
      <p>We'll notify you when your order ships.</p>
      <p>Thank you for shopping with us!</p>
    `

    // Prepare data for template
    const templateData = {
      customerName: order.customerInfo.name,
      orderId: order.id,
      items: order.items.map((item) => ({
        name: item.name,
        price: item.price.toFixed(2),
        quantity: item.quantity,
      })),
      total: order.total.toFixed(2),
    }

    // Render email template
    const html = renderEmailTemplate(emailTemplate, templateData)

    // Get store settings for the email subject
    const storeSettings = settings.store
    const storeName = storeSettings?.storeName || "Our Store"

    // Send email
    return await sendEmail(order.customerInfo.email, `Order Confirmation #${order.id} - ${storeName}`, html)
  } catch (error) {
    console.error("Failed to send order confirmation email:", error)
    return { success: false, error }
  }
}

// Send order status update email
export async function sendOrderStatusUpdateEmail(order: Order): Promise<{ success: boolean; error?: any }> {
  try {
    // Get notification settings
    const settings = await getSettings()
    const notificationSettings = settings.notifications

    // Check if email notifications and status updates are enabled
    if (!notificationSettings?.emailNotifications || !notificationSettings.orderStatusUpdate) {
      console.log("Order status update emails are disabled in settings")
      return { success: false, error: "Status update emails are disabled" }
    }

    // Get store settings
    const storeSettings = settings.store
    const storeName = storeSettings?.storeName || "Our Store"

    // Create status-specific content
    let statusTitle = ""
    let statusMessage = ""

    switch (order.status) {
      case "processing":
        statusTitle = "Your Order is Being Processed"
        statusMessage = "We're currently processing your order and will prepare it for shipping soon."
        break
      case "shipped":
        statusTitle = "Your Order Has Been Shipped"
        statusMessage = "Great news! Your order is on its way to you."
        break
      case "completed":
        statusTitle = "Your Order Has Been Completed"
        statusMessage = "Your order has been successfully completed. We hope you enjoy your purchase!"
        break
      case "cancelled":
        statusTitle = "Your Order Has Been Cancelled"
        statusMessage = "Your order has been cancelled. If you have any questions, please contact us."
        break
      default:
        statusTitle = "Order Status Update"
        statusMessage = `Your order status has been updated to: ${order.status}`
    }

    // Create email HTML
    const html = `
      <h1>${statusTitle}</h1>
      <p>Dear ${order.customerInfo.name},</p>
      <p>${statusMessage}</p>
      <p>Order #${order.id}</p>
      <h2>Order Details:</h2>
      <ul>
        ${order.items.map((item) => `<li>${item.quantity}x ${item.name} - $${item.price.toFixed(2)}</li>`).join("")}
      </ul>
      <p><strong>Total: $${order.total.toFixed(2)}</strong></p>
      <p>Thank you for shopping with us!</p>
      <p>The ${storeName} Team</p>
    `

    // Send email
    return await sendEmail(order.customerInfo.email, `Order Status Update: ${statusTitle} - ${storeName}`, html)
  } catch (error) {
    console.error("Failed to send order status update email:", error)
    return { success: false, error }
  }
}

