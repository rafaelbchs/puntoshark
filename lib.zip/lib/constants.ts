export const PRODUCTS_CACHE_TAG = "products"
export const ORDERS_CACHE_TAG = "orders"
export const INVENTORY_CACHE_TAG = "inventory"

