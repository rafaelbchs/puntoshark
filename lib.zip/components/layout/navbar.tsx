"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, ShoppingBag, User, Heart, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/context/cart-context"
import { useIsMobile } from "@/hooks/use-mobile"
import { CartDrawer } from "@/components/cart/cart-drawer"
import { Logo } from "./logo"

const navigationItems = [
  {
    name: "WOMEN",
    href: "/collections/women",
    subcategories: [
      {
        name: "Clothing",
        items: [
          { name: "T-Shirts", href: "/collections/women/t-shirts" },
          { name: "Sports Bras", href: "/collections/women/sports-bras" },
          { name: "Leggings", href: "/collections/women/leggings" },
          { name: "Shorts", href: "/collections/women/shorts" },
          { name: "Hoodies & Sweatshirts", href: "/collections/women/hoodies-sweatshirts" },
          { name: "Jackets", href: "/collections/women/jackets" },
        ],
      },
      {
        name: "Collections",
        items: [
          { name: "New Releases", href: "/collections/women/new-releases" },
          { name: "Bestsellers", href: "/collections/women/bestsellers" },
          { name: "Essentials", href: "/collections/women/essentials" },
          { name: "Seamless", href: "/collections/women/seamless" },
        ],
      },
    ],
  },
  {
    name: "MEN",
    href: "/collections/men",
    subcategories: [
      {
        name: "Clothing",
        items: [
          { name: "T-Shirts", href: "/collections/men/t-shirts" },
          { name: "Hoodies & Sweatshirts", href: "/collections/men/hoodies-sweatshirts" },
          { name: "Shorts", href: "/collections/men/shorts" },
          { name: "Joggers", href: "/collections/men/joggers" },
          { name: "Jackets", href: "/collections/men/jackets" },
          { name: "Tanks", href: "/collections/men/tanks" },
        ],
      },
      {
        name: "Collections",
        items: [
          { name: "New Releases", href: "/collections/men/new-releases" },
          { name: "Bestsellers", href: "/collections/men/bestsellers" },
          { name: "Essentials", href: "/collections/men/essentials" },
        ],
      },
    ],
  },
  {
    name: "ACCESSORIES",
    href: "/collections/accessories",
    subcategories: [
      {
        name: "Categories",
        items: [
          { name: "Bags", href: "/collections/accessories/bags" },
          { name: "Hats & Caps", href: "/collections/accessories/hats-caps" },
          { name: "Water Bottles", href: "/collections/accessories/water-bottles" },
        ],
      },
    ],
  },
]

interface NavbarProps {
  banner: any
}

export function Navbar({ banner }: NavbarProps) {
  console.log("Navbar received banner:", banner)

  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [cartOpen, setCartOpen] = useState(false)
  const [showBanner, setShowBanner] = useState(true)
  const { items, totalItems } = useCart()
  const isMobile = useIsMobile()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Close cart when navigating
  useEffect(() => {
    const handleRouteChange = () => {
      setCartOpen(false)
    }

    window.addEventListener("popstate", handleRouteChange)
    return () => {
      window.removeEventListener("popstate", handleRouteChange)
    }
  }, [])

  // Render the banner directly in the Navbar component
  const renderBanner = () => {
    console.log("Navbar: Rendering banner with data:", banner)

    // Check if banner exists, is enabled, and should be shown
    if (!banner || !banner.enabled || !showBanner) {
      console.log(
        "Navbar: Banner not shown because:",
        !banner ? "no banner data" : !banner.enabled ? "banner disabled" : "banner dismissed",
      )
      return null
    }

    // Check if banner should be shown based on dates
    const now = new Date()
    if (banner.startDate && new Date(banner.startDate) > now) {
      console.log("Navbar: Banner not shown because start date is in the future")
      return null
    }

    if (banner.endDate && new Date(banner.endDate) < now) {
      console.log("Navbar: Banner not shown because end date is in the past")
      return null
    }

    console.log("Navbar: Banner will be displayed")

    // Render the banner
    return (
      <div
        className="relative w-full"
        style={{
          backgroundColor: banner.bgColor || "#000000",
          color: banner.textColor || "#FFFFFF",
        }}
      >
        {banner.link ? (
          <Link href={banner.link} className="block">
            <div className="flex items-center justify-center text-center px-4 py-2 text-sm font-medium">
              {banner.text || "Promotional Banner"}
            </div>
          </Link>
        ) : (
          <div className="flex items-center justify-center text-center px-4 py-2 text-sm font-medium">
            {banner.text || "Promotional Banner"}
          </div>
        )}

        <button
          onClick={() => setShowBanner(false)}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 rounded-full hover:bg-black/10"
          aria-label="Dismiss banner"
        >
          <X className="h-4 w-4" style={{ color: banner.textColor || "#FFFFFF" }} />
        </button>
      </div>
    )
  }

  return (
    <>
      {/* Main header */}
      <header
        className="sticky top-0 left-0 right-0 z-50 bg-white"
        style={{
          boxShadow: isScrolled ? "0 1px 3px rgba(0,0,0,0.1)" : "none",
          transition: "box-shadow 0.3s",
        }}
      >
        {/* Render banner directly */}
        {renderBanner()}

        <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Logo />
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex lg:items-center lg:justify-center space-x-8">
              {navigationItems.map((item) => (
                <div key={item.name} className="relative group">
                  <Link href={item.href} className="text-sm font-medium text-gray-900 hover:text-black py-2">
                    {item.name}
                  </Link>

                  {/* Dropdown menu */}
                  <div className="absolute left-0 transform -translate-x-1/4 mt-2 w-screen max-w-5xl bg-white shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50 border-t border-gray-100">
                    <div className="grid grid-cols-2 gap-8 p-8">
                      {item.subcategories.map((category) => (
                        <div key={category.name}>
                          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">
                            {category.name}
                          </h3>
                          <ul className="space-y-4">
                            {category.items.map((subItem) => (
                              <li key={subItem.name}>
                                <Link href={subItem.href} className="text-sm text-gray-900 hover:text-black">
                                  {subItem.name}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Right Navigation */}
            <div className="flex items-center space-x-6">
              <button className="text-gray-900 hover:text-black hidden md:block">
                <Heart className="h-5 w-5" />
              </button>

              <Link href="/account" className="text-gray-900 hover:text-black hidden md:block">
                <User className="h-5 w-5" />
              </Link>

              <button className="relative text-gray-900 hover:text-black" onClick={() => setCartOpen(true)}>
                <ShoppingBag className="h-5 w-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-black text-[10px] text-white">
                    {totalItems}
                  </span>
                )}
              </button>

              {/* Mobile menu button */}
              <div className="lg:hidden">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="text-gray-900"
                >
                  <Menu className="h-6 w-6" />
                </Button>
              </div>
            </div>
          </div>
        </nav>
      </header>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-white">
          <div className="flex flex-col h-full overflow-y-auto pb-12 pt-4 px-4">
            <div className="flex items-center justify-between mb-6 border-b border-gray-200 pb-4">
              <Logo />
              <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(false)} className="text-gray-900">
                <Menu className="h-6 w-6" />
              </Button>
            </div>

            <div className="space-y-6">
              {navigationItems.map((item) => (
                <div key={item.name} className="py-2 border-b border-gray-200">
                  <Link
                    href={item.href}
                    className="text-base font-medium text-gray-900 block py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                  <div className="mt-3 space-y-6 pl-4">
                    {item.subcategories.map((category) => (
                      <div key={category.name} className="space-y-3">
                        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                          {category.name}
                        </h3>
                        <ul className="space-y-3">
                          {category.items.map((subItem) => (
                            <li key={subItem.name}>
                              <Link
                                href={subItem.href}
                                className="text-sm text-gray-900"
                                onClick={() => setMobileMenuOpen(false)}
                              >
                                {subItem.name}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              <div className="pt-4">
                <Link
                  href="/account"
                  className="text-base font-medium text-gray-900 block py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Account
                </Link>
                <Link
                  href="/wishlist"
                  className="text-base font-medium text-gray-900 block py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Wishlist
                </Link>
                <Link
                  href="/help"
                  className="text-base font-medium text-gray-900 block py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Help
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cart drawer */}
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </>
  )
}

