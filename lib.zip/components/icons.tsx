import { X } from "lucide-react"

export const Icons = {
  close: X,
}

